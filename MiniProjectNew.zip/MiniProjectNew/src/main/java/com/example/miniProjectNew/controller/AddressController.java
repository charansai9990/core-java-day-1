package com.example.miniProjectNew.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.miniProjectNew.model.Address;
import com.example.miniProjectNew.service.AddressService;


@RestController("/api")
public class AddressController {
	
	AddressService addressService;
	
	
	@PostMapping("add")
	public ResponseEntity<Address> saveEmployees(@RequestBody Address address ){
		return new ResponseEntity<Address>(addressService.saveAdress(address),HttpStatus.CREATED);
		}
}

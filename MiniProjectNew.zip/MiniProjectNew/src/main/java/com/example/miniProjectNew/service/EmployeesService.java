package com.example.miniProjectNew.service;

import java.util.List;


import com.example.miniProjectNew.model.Employees;

public interface EmployeesService {
	
	Employees saveEmployees(Employees employees);
	
 List<Employees> getAllEmployees ();

Employees getEmployeesById(int id);

Employees updateEmployeeById(Employees employee, int id);

void deleteEmployeeByID(int id);
	
	
}
	


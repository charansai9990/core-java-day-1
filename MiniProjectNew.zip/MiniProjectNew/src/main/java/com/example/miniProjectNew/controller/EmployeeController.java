package com.example.miniProjectNew.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;

//import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.example.miniProjectNew.model.Employees;
import com.example.miniProjectNew.service.EmployeesService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	private EmployeesService employeesService;

	
	
	
	public EmployeeController(EmployeesService employeesService) {
		super();
		this.employeesService = employeesService;
	}
	
@GetMapping("getAll")
public List<Employees> saveEmployees(){

return employeesService.getAllEmployees();
}
	

@PostMapping("add")
public ResponseEntity<Employees> saveEmployees(@RequestBody Employees employees ){
	
	return new ResponseEntity<Employees>(employeesService.saveEmployees(employees),HttpStatus.CREATED);
}

@GetMapping("getId/{id}")
public Employees getEmployeesById(@PathVariable int id) {
	
	Employees employees= employeesService.getEmployeesById(id);
	return employees;
}

@PutMapping("updateById/{id}")
public ResponseEntity<Employees> updateEmployeesById(@PathVariable("id") int id,@RequestBody Employees employees){
	return new ResponseEntity<Employees> (employeesService.updateEmployeeById(employees, id),HttpStatus.OK);
}


@DeleteMapping("deleteById/{id}")
	public ResponseEntity<String> deleteEmployeesById(@PathVariable("id") int id ){
		
		employeesService.deleteEmployeeByID(id);
		return new ResponseEntity<String>("Employee  "+ id+"  deleted  Succeefully",HttpStatus.OK);


}


 
	



//@GetMapping("/getAllEmployee")
// List<Employees> getEmployees(){ 
//	return employeesService.getAllEmployees() ;
//	

	
	
}


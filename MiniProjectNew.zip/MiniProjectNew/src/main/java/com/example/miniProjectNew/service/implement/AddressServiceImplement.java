package com.example.miniProjectNew.service.implement;

import java.util.List;

import com.example.miniProjectNew.model.Address;
import com.example.miniProjectNew.repository.AddressRepository;
import com.example.miniProjectNew.service.AddressService;

public class AddressServiceImplement implements AddressService{
AddressRepository addressRepository;
	
	@Override
	public Address saveAdress(Address address) {
		
		return addressRepository.save(address) ;
	}


	public List<Address> getAllAddress() {
		
		return null;
	}

	@Override
	public Address getAddressById(int ea_fk) {
		
		
		return null;
	}

	@Override
	public Address updateAddressById(Address address, int ea_fk) {
		
		
		return null;
	}

	@Override
	public void deleteAddressByID(int ea_fk) {
		
		
		
	}

}

package com.example.miniProjectNew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniProjectNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniProjectNewApplication.class, args);
		
		System.out.println("Project Was Running Successfully" );
	}
}
package com.example.miniProjectNew.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.miniProjectNew.model.Employees;

public interface EmployeesRepository extends JpaRepository<Employees,Integer> {

	
	Employees  findById(int id);
	
	
}



package com.example.miniProjectNew.service.implement;
import java.util.List;



//import java.util.List;
import org.springframework.stereotype.Service;
import com.example.miniProjectNew.model.Employees;
import com.example.miniProjectNew.repository.EmployeesRepository;
import com.example.miniProjectNew.service.EmployeesService;


@Service

public class EmployeesServicesImplement implements EmployeesService {
 
	private EmployeesRepository employeesRepository;

	
	public EmployeesServicesImplement(EmployeesRepository employeesRepository) {
		super();
		this.employeesRepository = employeesRepository;
	}
	
//	@Override
//	public Employees saveEmployees(Employees employees) {
//	System.out.println("Employee Data "+employees);
//		return employeesRepository.save(employees);
//	}

//	@Override
//	public List<Employees> getAllEmployees () {
//		
//		return employeesRepository.findAll();
//	}
	
@Override
public Employees saveEmployees(Employees employees) {

	return employeesRepository.save(employees);
}

@Override
public List<Employees> getAllEmployees() {
	
	return employeesRepository.findAll();
}

@Override
public Employees getEmployeesById(int id) {
	return employeesRepository.findById(id);
	
}

@Override
public Employees updateEmployeeById(Employees employees, int id) {

	Employees existEmployees= employeesRepository.findById(id);

	existEmployees.setId(employees.getId());
	existEmployees.setFirstName(employees.getFirstName());
	existEmployees.setLastName(employees.getLastName());
	existEmployees.setAge(employees.getAge());
	existEmployees.setGender(employees.getGender());
	existEmployees.setDesignation(employees.getDesignation());
	existEmployees.setEmail(employees.getEmail());	
	employeesRepository.save(existEmployees);
	return existEmployees;
}

@Override
public void deleteEmployeeByID(int id) {

		employeesRepository.findById(id);
		employeesRepository.deleteById(id);
	}
	
}



//@Override
// public Employees getEmployeesById(Employees emplyoyes) {
//	return employeesRepository.getById(Int);
//	 
// }
	
	


package com.example.miniProjectNew.service;

import java.util.List;

import com.example.miniProjectNew.model.Address;
public interface AddressService {
	
	


	

		
		Address saveAdress(Address address);
		
	 List<Address> getAllAddress ();

	Address getAddressById(int ea_fk);

	Address updateAddressById(Address address, int ea_fk);

	void deleteAddressByID(int ea_fk);
		
		
	}
		





package com.example.miniProjectNew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniProjectNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
